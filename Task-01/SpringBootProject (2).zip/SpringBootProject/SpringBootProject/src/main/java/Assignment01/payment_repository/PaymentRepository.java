package Assignment01.payment_repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import Assignment01.payment_pojo.Payment;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Integer> {

}
