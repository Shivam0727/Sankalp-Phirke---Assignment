package Assignment01.payment_controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import Assignment01.payment_pojo.Payment;
import Assignment01.payment_service.PaymentService;

@RestController
public class PaymentController {

	@Autowired
	private PaymentService paymentService ;
	
	// API For Add A Particular Payment Detail :
	@PostMapping("/AddPaymentDetails")
	public String AddPaymentDetails(@RequestBody Payment payment) {
		return paymentService.AddPaymentDetails(payment);
	}
	
	// API For Update A Particular Payment Detail :
	@PutMapping("/UpdatePaymentDetails")
	public String UpdatePaymentDetails(@RequestBody Payment payment) {
		return paymentService.UpdatePaymentDetails(payment);
	}
	
	// API For Delete A Particular Payment Detail :
	@DeleteMapping("/DeletePaymentByPaymentId/{paymentId}")
	public String DeletePaymentDetails(@PathVariable int paymentId) {
		return paymentService.DeletePaymentDetails(paymentId);
	}
	
	// API For Search A Particular Payment Detail :
	@GetMapping("/SearchPaymentDetailsByPaymentId/{paymentId}")
	public String SearchPaymentDetails(@PathVariable int paymentId) {
		return paymentService.SearchPaymentDetails(paymentId);
	}
	
	// API For Fetch All Payment Detail :
	@GetMapping("/GetAllPaymentDetails")
	public List<Payment> GetAllPaymentDetails() {
		return paymentService.GetAllPaymentDetails();
	}
	
}
