package Assignment01.payment_pojo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Payment_Details")
public class Payment 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="Payment_Id")
	private int paymentId;
	@Column(name="Payment_Status")
	private String status;
	@Column(name="Transaction_Id")
	private String transactionId;
	@Column(name="Price")
	private double price; 
	@Column(name="Order_Id")
	private int orderId;
	
	// Getter-Setter Method : 
	public int getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	
	// Parameterized Constructor :
	public Payment(int paymentId, String status, String transactionId, double price, int orderId) {
		super();
		this.paymentId = paymentId;
		this.status = status;
		this.transactionId = transactionId;
		this.price = price;
		this.orderId = orderId;
	}
	
	// Default Constructor :
	public Payment() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	// ToString Method : 
	@Override
	public String toString() {
		return "Payment [paymentId=" + paymentId + ", status=" + status + ", transactionId=" + transactionId
				+ ", price=" + price + ", orderId=" + orderId + "]";
	}
	
}
