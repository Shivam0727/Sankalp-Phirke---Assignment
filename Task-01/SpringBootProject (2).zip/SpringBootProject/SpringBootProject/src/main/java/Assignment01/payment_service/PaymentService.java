package Assignment01.payment_service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Assignment01.payment_pojo.Payment;
import Assignment01.payment_repository.PaymentRepository;

@Service
public class PaymentService {
	
	@Autowired
	private PaymentRepository paymentRepository ;
	
	// Method For Add A Particular Payment Detail :
	public String AddPaymentDetails(Payment payment) {
		paymentRepository.save(payment);
		return "Congratulatios , Your Payment Added Successfully !S!!";
	}
	
	// Method To Check A Particular Payment Detail If Exist Or Not :
	public boolean CheckPaymentDetails(int paymentId) {
		boolean check = paymentRepository.existsById(paymentId);
		return check ;
	}
	
	// Method For Update A Particular Payment Detail :
	public String UpdatePaymentDetails(Payment payment) {
		int paymentId = payment.getPaymentId();
		boolean check = CheckPaymentDetails(paymentId);
		if(check) {
			paymentRepository.save(payment);
			return "Congratulations , Payment Details Update Successfully !!!";
		}
		return "Sorry , PaymentId Does Not Exist !!!";
	}
	
	// Method For Delete A Particular Payment Detail :
	public String DeletePaymentDetails(int paymentId) {
		boolean check = CheckPaymentDetails(paymentId);
		if(check) {
			paymentRepository.deleteById(paymentId);
			return "Congratulations , Payment Details Deleted Successfully ...";
		}
		return "Sorry , PaymentId Does Not Exist !!!";
	}
	
	// Method For Search A Particular Single Payment Detail : 
	public String SearchPaymentDetails(int paymentId) {
		boolean check = CheckPaymentDetails(paymentId);
		if(check) {
			Optional<Payment> details = paymentRepository.findById(paymentId);
			return "Transaction Id : "+details.get().getTransactionId()+"\nAmount : "+details.get().getPrice()+"\nOrder Id : "+details.get().getOrderId()+"\nStatus : "+details.get().getStatus();
		}
		return "Sorry , PaymentId Does Not Exist !!!";
	}
	
	// Method For Fetch All The Payment Details :
	public List<Payment> GetAllPaymentDetails() {
		return paymentRepository.findAll();
	}
}
